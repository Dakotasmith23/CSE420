Jacob Bennett- 5242085 & Dakota Smith- 5162129

Did you fully implement the project as described? If not, what parts are not implemented
at all or not implemented by following the specified implementation rules?

Only the last part of the project does not pass the test (test 5). This is because we are not utilizing the indirect blocks. All other parts of the project follow implementation as specified.
