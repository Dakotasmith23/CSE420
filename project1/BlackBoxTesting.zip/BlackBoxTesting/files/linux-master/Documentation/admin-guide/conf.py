# -*- coding: utf-8; mode: python -*-

project = 'Linux Kernel User Documentation'

tags.add("subproject")

latex_documents = [
    ('index', 'linux-user.tex', 'Linux Kernel User Documentation',
     'The kernel development community', 'manual'),
]
