================
Power Management
================

.. toctree::
   :maxdepth: 2

   cpufreq
   intel_pstate

.. only::  subproject and html

   Indices
   =======

   * :ref:`genindex`
