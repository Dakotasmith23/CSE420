# -*- coding: utf-8; mode: python -*-

project = 'Linux Kernel Crypto API'

tags.add("subproject")

latex_documents = [
    ('index', 'crypto-api.tex', 'Linux Kernel Crypto API manual',
     'The kernel development community', 'manual'),
]
