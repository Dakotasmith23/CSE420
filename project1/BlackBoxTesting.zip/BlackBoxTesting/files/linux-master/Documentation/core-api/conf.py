# -*- coding: utf-8; mode: python -*-

project = "Core-API Documentation"

tags.add("subproject")

latex_documents = [
    ('index', 'core-api.tex', project,
     'The kernel development community', 'manual'),
]
