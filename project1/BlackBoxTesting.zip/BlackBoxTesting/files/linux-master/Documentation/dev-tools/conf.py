# -*- coding: utf-8; mode: python -*-

project = "Development tools for the kernel"

tags.add("subproject")

latex_documents = [
    ('index', 'dev-tools.tex', project,
     'The kernel development community', 'manual'),
]
